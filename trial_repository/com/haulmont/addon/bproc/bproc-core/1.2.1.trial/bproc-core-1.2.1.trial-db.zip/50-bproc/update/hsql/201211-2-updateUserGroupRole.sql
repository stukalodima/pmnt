alter table BPROC_USER_GROUP_ROLE add column SYS_TENANT_ID varchar(255)^
