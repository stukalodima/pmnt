alter table BPROC_USER_GROUP add SYS_TENANT_ID varchar(255)^
alter table BPROC_USER_GROUP add SYS_TENANT_ID_NN varchar(255) not null default 'no_tenant'^
alter table BPROC_USER_GROUP add DELETE_TS_NN datetime(3) not null default '1000-01-01 00:00:00.000'^

drop index IDX_BPROC_USER_GROUP_UNIQ_CODE on BPROC_USER_GROUP^
create unique index IDX_BPROC_USER_GROUP_UNIQ_CODE_TENANT on BPROC_USER_GROUP (CODE, SYS_TENANT_ID_NN, DELETE_TS_NN)^

create trigger BPROC_USER_GROUP_SYS_TENANT_ID_NN_INSERT_TRIGGER before insert on BPROC_USER_GROUP
for each row set NEW.SYS_TENANT_ID_NN = if (NEW.SYS_TENANT_ID is null, 'no_tenant', NEW.SYS_TENANT_ID)^

create trigger BPROC_USER_GROUP_SYS_TENANT_ID_NN_UPDATE_TRIGGER before update on BPROC_USER_GROUP
for each row
begin
    if not(NEW.SYS_TENANT_ID <=> OLD.SYS_TENANT_ID) then
		set NEW.SYS_TENANT_ID_NN = NEW.SYS_TENANT_ID;
	end if;
    if not(NEW.DELETE_TS <=> OLD.DELETE_TS) then
        set NEW.DELETE_TS_NN = if (NEW.DELETE_TS is null, '1000-01-01 00:00:00.000', NEW.DELETE_TS);
    end if;
end^
