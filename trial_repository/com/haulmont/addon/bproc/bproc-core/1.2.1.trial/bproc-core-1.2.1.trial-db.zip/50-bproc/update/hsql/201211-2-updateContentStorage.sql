alter table BPROC_CONTENT_STORAGE add column SYS_TENANT_ID varchar(255)^
