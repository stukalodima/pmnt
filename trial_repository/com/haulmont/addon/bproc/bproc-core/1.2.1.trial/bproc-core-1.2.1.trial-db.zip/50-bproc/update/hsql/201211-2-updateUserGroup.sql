alter table BPROC_USER_GROUP add column SYS_TENANT_ID varchar(255)^

alter table BPROC_USER_GROUP add constraint IDX_BPROC_USER_GROUP_UNIQ_CODE_TENANT unique (CODE, SYS_TENANT_ID)^