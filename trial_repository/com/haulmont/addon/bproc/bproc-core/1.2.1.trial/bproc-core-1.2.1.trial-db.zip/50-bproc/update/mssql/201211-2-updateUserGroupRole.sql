alter table BPROC_USER_GROUP_ROLE add SYS_TENANT_ID varchar(255)^
