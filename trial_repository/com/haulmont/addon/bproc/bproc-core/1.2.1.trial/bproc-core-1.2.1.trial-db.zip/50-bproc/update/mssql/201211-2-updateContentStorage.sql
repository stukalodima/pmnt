alter table BPROC_CONTENT_STORAGE add SYS_TENANT_ID varchar(255)^
