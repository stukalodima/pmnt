alter table BPROC_USER_GROUP add column SYS_TENANT_ID varchar(255)^

drop index IDX_BPROC_USER_GROUP_UK_CODE^
create unique index IDX_BPROC_USER_GROUP_UK_CODE on BPROC_USER_GROUP (CODE)
    where DELETE_TS is null and SYS_TENANT_ID is null;
create unique index IDX_BPROC_USER_GROUP_UK_CODE_TENANT on BPROC_USER_GROUP (CODE, SYS_TENANT_ID)
    where DELETE_TS is null and SYS_TENANT_ID is not null^