create table BPROC_USER_GROUP_ROLE (
    ID varchar2(32),
    VERSION number(10) not null,
    CREATE_TS timestamp,
    CREATED_BY varchar2(50 char),
    UPDATE_TS timestamp,
    UPDATED_BY varchar2(50 char),
    DELETE_TS timestamp,
    DELETED_BY varchar2(50 char),
    --
    USER_GROUP_ID varchar2(32) not null,
    ROLE_NAME varchar2(255 char),
    ROLE_ID varchar2(32),
    --
    primary key (ID)
)^

alter table BPROC_USER_GROUP_ROLE add constraint FK_USER_GROUP_ROLE_USER_GROUP foreign key (USER_GROUP_ID) references BPROC_USER_GROUP(ID)^
alter table BPROC_USER_GROUP_ROLE add constraint FK_USER_GROUP_ROLE_SEC_ROLE foreign key (ROLE_ID) references SEC_ROLE(ID)^

create index IDX_USER_GROUP_ROLE_USER_GROUP on BPROC_USER_GROUP_ROLE (USER_GROUP_ID)^
create index IDX_USER_GROUP_ROLE_SEC_ROLE on BPROC_USER_GROUP_ROLE (ROLE_ID)^