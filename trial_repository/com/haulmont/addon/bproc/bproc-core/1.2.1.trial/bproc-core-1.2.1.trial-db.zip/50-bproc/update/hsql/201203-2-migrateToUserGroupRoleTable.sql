insert into BPROC_USER_GROUP_ROLE (
    ID,
    CREATE_TS,
    CREATED_BY,
    VERSION,
    UPDATE_TS,
    UPDATED_BY,
    USER_GROUP_ID,
    ROLE_ID
)
select
    newid(),
    ug.CREATE_TS,
    ug.CREATED_BY,
    ug.VERSION,
    ug.UPDATE_TS,
    ug.UPDATED_BY,
    ug.ID,
    ugr.ROLE_ID
from BPROC_USER_GROUP ug join BPROC_USER_GROUP_ROLE_LINK ugr on ug.ID = ugr.USER_GROUP_ID^
