alter table BPROC_USER_GROUP_ROLE add SYS_TENANT_ID varchar2(255 char)^
