alter table BPROC_CONTENT_STORAGE add SYS_TENANT_ID varchar2(255 char)^
