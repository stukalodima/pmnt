create table BPROC_USER_GROUP_ROLE (
    ID uuid,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    USER_GROUP_ID uuid not null,
    ROLE_NAME varchar(255),
    ROLE_ID uuid,
    --
    primary key (ID)
)^

alter table BPROC_USER_GROUP_ROLE add constraint FK_BPROC_USER_GROUP_ROLE_USER_GROUP foreign key (USER_GROUP_ID) references BPROC_USER_GROUP(ID)^
alter table BPROC_USER_GROUP_ROLE add constraint FK_BPROC_USER_GROUP_ROLE_SEC_ROLE foreign key (ROLE_ID) references SEC_ROLE(ID)^

create index IDX_BPROC_USER_GROUP_ROLE_USER_GROUP on BPROC_USER_GROUP_ROLE (USER_GROUP_ID)^
create index IDX_BPROC_USER_GROUP_ROLE_SEC_ROLE on BPROC_USER_GROUP_ROLE (ROLE_ID)^